#include <stdio.h>

int main()
{
	int a,b,c;
	
	a=2;
	b=3;
	c= a + b;
	
	printf("total:%d",c);

	return 0;
}
