#include <stdio.h>
int main()
{
	int my=45;
	
	printf("hello\n");
	printf("para:<%d>",my);

	return 0;
}
